package com.example.practical8;

public class Contact {
    private String name;
    private String number;
    private int id;
    public int getid()
    {
        return id;
    }
    public String getName()
    {
        return name;
    }
    public String getNum()
    {
        return number;
    }
    public void setid(int id)
    {
        this.id=id;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public void setNum(String number)
    {
        this.number=number;
    }
}
